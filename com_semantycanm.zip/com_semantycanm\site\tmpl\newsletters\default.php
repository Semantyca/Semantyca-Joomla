<?php

use Joomla\CMS\HTML\HTMLHelper;

HTMLHelper::_('form.csrf', '_csrf');

$this->newsLetters     = $this->news_letters;

?>

<div class="bd-example">
   <h3>Coming soon...</h3>
</div>

