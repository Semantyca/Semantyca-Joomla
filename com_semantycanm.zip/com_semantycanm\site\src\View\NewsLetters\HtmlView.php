<?php

namespace Semantyca\Component\SemantycaNM\Site\View\Dashboard;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

class HtmlView extends BaseHtmlView
{
	function display($tpl = null)
	{
		parent::display($tpl);
	}
}
