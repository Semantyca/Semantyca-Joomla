<?php

namespace Semantyca\Component\SemantycaNM\Administrator\Exception;
class UpdateRecordException extends \Exception
{

}
