<template>
  <div>
    <p>Hello from Vue!</p>
  </div>
</template>

<script>
import {defineComponent} from 'vue';

export default defineComponent({
  name: 'SimpleTemplateEditor',
  setup() {

    return {};
  }
});
</script>

<style scoped>

</style>
