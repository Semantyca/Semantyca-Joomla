<?php

namespace Semantyca\Component\SemantycaNM\Administrator;

use Joomla\CMS\Component\Router\RouterInterface;

class Router implements RouterInterface {
	public function build(&$query) {

	}

	public function parse(&$segments) {

	}

	public function preprocess($query)
	{

	}
}
