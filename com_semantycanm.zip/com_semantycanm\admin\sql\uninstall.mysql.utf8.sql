DROP TABLE IF EXISTS `#__semantyca_nm_subscriber_events`;
DROP TABLE IF EXISTS `#__semantyca_nm_stats`;
DROP TABLE IF EXISTS `#__semantyca_nm_newsletters`;
DROP TABLE IF EXISTS `#__semantyca_nm_mailing_list_rel_usergroups`;
DROP TABLE IF EXISTS `#__semantyca_nm_custom_fields`;
DROP TABLE IF EXISTS `#__semantyca_nm_mailing_list`;
DROP TABLE IF EXISTS `#__semantyca_nm_templates`;
